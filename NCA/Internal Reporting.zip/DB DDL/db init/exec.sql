exec dbo.[usp_SPStateLoad]
exec [dbo].[usp_SPSeniorityLoad]
exec dbo.[usp_SPPersonLoad]
exec [dbo].[usp_PASeniorityScoreLoad]
exec dbo.usp_PARelationLoad
exec dbo.usp_PAMarkLoad
exec [dbo].[usp_PAKPITypeLoad]
exec [dbo].[usp_PAKPILoad]
exec [dbo].[usp_PAContextCategoryLoad]
exec dbo.usp_PAGradeLoad
exec dbo.usp_PAContextLoad
exec dbo.usp_PAEvaluationPeerLoad
exec dbo.usp_PAContextStateLoad
exec dbo.usp_PAEPFeedbackLoad


exec [dbo].[PA_SP_MainLoad]
